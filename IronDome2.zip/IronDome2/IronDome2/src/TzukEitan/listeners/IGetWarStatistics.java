package TzukEitan.listeners;

import TzukEitan.war.WarStatistics;

public interface IGetWarStatistics {

	public WarStatistics getWarStatistics();
}
